#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc
print "This is script.libreelecpi starting and stopping"
exit()