import xbmc


print "********************************************************************"
print "This is randomlastitems saying stuff this for a game of soldiers"
exit()
