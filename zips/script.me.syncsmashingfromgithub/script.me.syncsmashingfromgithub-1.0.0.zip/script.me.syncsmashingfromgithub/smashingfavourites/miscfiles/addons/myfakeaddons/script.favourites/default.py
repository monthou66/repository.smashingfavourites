# Credits to CF2009 for the original favourites script.

import xbmc

print 'favourites script is going on holiday.'

exit()
