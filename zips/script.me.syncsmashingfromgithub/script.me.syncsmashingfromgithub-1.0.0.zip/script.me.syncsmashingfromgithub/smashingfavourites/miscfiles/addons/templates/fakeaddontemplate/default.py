#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc
print "This is *putclone_namehere* starting and stopping"
exit()
