#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc
print "This is library data provider default.py saying bye bye and thanks for all ze fish"
exit()
