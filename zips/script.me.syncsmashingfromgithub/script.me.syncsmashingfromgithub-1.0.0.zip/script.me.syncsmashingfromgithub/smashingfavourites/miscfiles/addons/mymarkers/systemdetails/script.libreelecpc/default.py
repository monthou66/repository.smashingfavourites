#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc
print "This is script.libreelecpc starting and stopping"
exit()