#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc
print "This is script.windows32 starting and stopping"
exit()