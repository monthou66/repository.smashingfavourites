#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc
print "This is script.libreelecarm64 starting and stopping"
exit()