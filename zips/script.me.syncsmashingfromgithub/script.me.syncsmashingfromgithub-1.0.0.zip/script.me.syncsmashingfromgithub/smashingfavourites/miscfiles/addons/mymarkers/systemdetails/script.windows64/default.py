#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc
print "This is script.windows64 starting and stopping"
exit()