#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc
print "This is script.android32 starting and stopping"
exit()